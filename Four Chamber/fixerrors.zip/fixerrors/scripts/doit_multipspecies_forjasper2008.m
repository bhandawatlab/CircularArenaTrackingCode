addpath /home/kristin/FLIES/data/multiplespecies/;
setmultispeciesmovienames;
DISPLAYAREAS = true;
fixmanymovies;