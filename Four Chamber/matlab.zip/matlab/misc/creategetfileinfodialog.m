function h = creategetfileinfodialog(msg)

title = 'What am I opening?';
h = createfileinfodialog(msg,title);
