function deletefileinfodialog(h)

if ishandle(h),
  delete(h);
end
