function h = createputfileinfodialog(msg)

title = 'What am I saving?';
h = createfileinfodialog(msg,title);