function ctrax_matlab_filehandling_check()

fprintf('Yes, you have the Ctrax matlab/filehandling code!\n');

